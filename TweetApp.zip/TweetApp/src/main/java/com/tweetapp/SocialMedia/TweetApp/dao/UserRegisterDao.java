package com.tweetapp.SocialMedia.TweetApp.dao;


import com.tweetapp.SocialMedia.TweetApp.model.RegisterDto;

public interface UserRegisterDao extends JpaRepository<RegisterDto,Long> {
	
	void save(RegisterDto data);
	
	
	

	
}
