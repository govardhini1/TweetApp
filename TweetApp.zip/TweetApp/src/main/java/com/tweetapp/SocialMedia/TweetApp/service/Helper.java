package com.tweetapp.SocialMedia.TweetApp.service;

public class Helper {

	
    private boolean F1=true;

	public boolean isF1() {
		return F1;
	}

	public void setF1(boolean F1) {
		this.F1 = F1;
	}

	
	
	
}
