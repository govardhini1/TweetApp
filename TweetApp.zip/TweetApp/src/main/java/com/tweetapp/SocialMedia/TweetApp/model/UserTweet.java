package com.tweetapp.SocialMedia.TweetApp.model;


import javax.persistence.Table;

@Table(name="User_tweet")
public class UserTweet {
	
	private Long id;
	private String email;
	private String tweet;
	private String date;
	public UserTweet(Long id, String email, String tweet, String date) {
		super();
		this.id = id;
		this.email = email;
		this.tweet = tweet;
		this.date = date;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	

}
