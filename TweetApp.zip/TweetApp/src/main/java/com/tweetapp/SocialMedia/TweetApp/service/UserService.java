package com.tweetapp.SocialMedia.TweetApp.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserService {
	
	

	Helper h1=new Helper();

	public void login(String email,String password) {
		Connection con=null;
		PreparedStatement ps=null;
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TweetApp","root","root");
				ps=con.prepareStatement("select * from user where email=?");
				ps.setString(1, email);
				ResultSet rs=ps.executeQuery();

				while(rs.next()) {
					
					if(rs.getString(6).equalsIgnoreCase(email) && rs.getString(7).equalsIgnoreCase(password)) {
						
						 h1.setF1(true);
						
						System.out.println("Sucessfully logged in!");
						
						
					}
					
				
					else {
						System.out.println("Invalid Credentials");
					}
			}
				
			}
				catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
						
				
			}
	
}
