package com.tweetapp.SocialMedia.TweetApp.dao;

public interface JpaRepository<T1, T2> {

}
