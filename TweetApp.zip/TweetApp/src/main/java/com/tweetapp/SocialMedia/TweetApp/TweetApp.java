package com.tweetapp.SocialMedia.TweetApp;

import java.util.Scanner;

import java.util.regex.Pattern;

import com.tweetapp.SocialMedia.TweetApp.model.RegisterDto;
import com.tweetapp.SocialMedia.TweetApp.model.UserTweet;
import com.tweetapp.SocialMedia.TweetApp.service.Helper;
import com.tweetapp.SocialMedia.TweetApp.service.RegisterService;
import com.tweetapp.SocialMedia.TweetApp.service.TweetService;
import com.tweetapp.SocialMedia.TweetApp.service.UserService;

public class TweetApp {
	public static String firstName;
	public static String lastName;
	public static String gender;
	public static String dob;
	public static String email;
	public static String password;
	public static Long id;
	public static String tweet;
	public static String date;

	public static void main(String[] args) {

		RegisterService registerservice = new RegisterService();
		TweetService tweetService = new TweetService();
		UserService userservice = new UserService();
		Helper h1 = new Helper();

		Scanner sc = new Scanner(System.in);
		int choice;
		System.out.println("Enter 1 for Registeration");
		System.out.println("Enter 2 to view the Tweet");
		System.out.println("Enter 3 to login and password Reset");
		System.out.println("Enter 4 for post the Tweet ");
		choice = sc.nextInt();

		switch (choice) {
		case 1:
			sc.nextLine();
			System.out.println("Enter the first name");
			firstName = sc.nextLine();

			System.out.println("Enter the last name");
			lastName = sc.nextLine();
			System.out.println("Enter the gender(M/F)");
			gender = sc.nextLine();
			System.out.println("Enter the dob");
			System.out.println("Enter the dob in (DD-MM-YYYY");
			dob = sc.nextLine();
			System.out.println("Enter the email");

			email = sc.nextLine();

			System.out.println("Enter the password");
			password = sc.nextLine();

			System.out.println("Enter the id");
			id = sc.nextLong();

			RegisterDto data = new RegisterDto(firstName, lastName, gender, dob, email, password, id);
			if (validEmail(email) == true) {
				registerservice.userRegister(data);
			} else {
				System.out.println("Please enter the valid Email and password");
			}
			break;

		case 2:
			sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			
				tweetService.viewTweet(email);
			
			break;
		case 3:
			sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			System.out.println("Enter the password");
			password = sc.nextLine();
			
				userservice.login(email, password);

			

			if (h1.isF1() == true) {

				System.out.println("Do you want to reset password?");
				Boolean F = sc.hasNextBoolean();

				if (F) {
					sc.nextLine();
					System.out.println("Enter your new password");
					String password1 = sc.nextLine();
					
						tweetService.passwordReset(email, password1);
					
				}
			}

			break;

		case 4:
			sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			System.out.println("Enter the id");
			id = sc.nextLong();
			System.out.println("Enter the tweet");
			tweet = sc.nextLine();
			UserTweet data1 = new UserTweet(id, email, tweet, date);
			
				tweetService.postTweet(data1);
			 
			break;
		}

	}

	
	public static boolean validEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";

		Pattern pat = Pattern.compile(emailRegex);
		if (email == null) {
			return false;
		}
		return pat.matcher(email).matches();

	}
}
