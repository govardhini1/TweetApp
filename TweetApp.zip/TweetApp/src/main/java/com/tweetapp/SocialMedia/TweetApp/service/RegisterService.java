package com.tweetapp.SocialMedia.TweetApp.service;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.tweetapp.SocialMedia.TweetApp.dao.UserRegisterDao;

import com.tweetapp.SocialMedia.TweetApp.model.RegisterDto;

public class RegisterService {

	   UserRegisterDao userRegister;
	   public Connection con=null;
		public PreparedStatement ps=null;
		
		
 public void userRegister(RegisterDto data) {
	
		 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TweetApp","root","root");
		ps=con.prepareStatement("insert into user values(?,?,?,?,?,?,?)");
		ps.setLong(1,data.getId());
		ps.setString(2,data.getFirstName());
		ps.setString(3,data.getLastName());
		ps.setString(4,data.getGender());
		ps.setString(5,data.getDob());
		ps.setString(6,data.getEmail());
		ps.setString(7,data.getPassword());
		
		
		ps.executeUpdate();
		System.out.println("Registered Sucessfully!");
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 }
}
	  
	    
	  
 
 
	 
	 
 
	 
