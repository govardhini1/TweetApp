package com.tweetapp.SocialMedia.TweetApp.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.tweetapp.SocialMedia.TweetApp.dao.UserRegisterDao;
import com.tweetapp.SocialMedia.TweetApp.model.UserTweet;



public class TweetService {
 
	UserRegisterDao userRegister;
	public Connection con=null;
	public PreparedStatement ps=null;
	
	public void viewTweet(String email) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TweetApp","root","root");
			ps=con.prepareStatement("select * from User_tweet where email=?");
			ps.setString(1, email);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getString(2) + "posted:\n " +rs.getString(3) + "at " + rs.getString(4));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		public void postTweet(UserTweet data1) {
			
				 LocalDateTime date=LocalDateTime.now();
				 DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"); 
				  String formatedDate=date.format(format);
				
						try {
							Class.forName("com.mysql.cj.jdbc.Driver");
							con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TweetApp","root","root");
							ps=con.prepareStatement("insert into user_tweet values(?,?,?,?)");
							ps.setLong(1,data1.getId());
							ps.setString(2,data1.getEmail());
							ps.setString(3,data1.getTweet());
							ps.setString(4,formatedDate);
							ps.executeUpdate();
							System.out.println("posted Sucessfully!");
						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				
			 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
	public void passwordReset(String email,String password) {
		
		
			try {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TweetApp","root","root");
					ps=con.prepareStatement("update user set password=? where  email=?");
					ps.setString(1, password);
					ps.setString(2,email);
					ps.executeUpdate();
					System.out.println("Sucessfully reset the password!");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
